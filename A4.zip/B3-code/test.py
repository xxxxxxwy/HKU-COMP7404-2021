import os
from bs4 import BeautifulSoup
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
import re


# preprocess
def get_text(path):
    texts = []
    files = os.listdir(path)
    for file in files:
        with open(os.path.join(path, file), encoding='utf8', errors='ignore') as f:
            content = f.read()
            try:
                soup = BeautifulSoup(content, 'html.parser')
                content = soup.get_text()
                results = re.compile(r'[http|https]*://[a-zA-Z0-9.?/&=:]*', re.S)
                content = re.sub(results, '', content)
                results = re.compile(r'[www]*://[a-zA-Z0-9.?/&=:]*', re.S)
                content = re.sub(results, '', content)
                content = re.sub(r'[0-9]+', '', content)
                content = re.sub(r'[\n|\r|\t\|' ']+', '', content)
            except:
                pass
        texts.append(content)
    return texts


spam_path = './data/spam_data/spam'
spam_content = get_text(spam_path)
# print(len(spam_content)) 501

ham_path = './data/ham_data/hard_ham'
ham_content = get_text(ham_path)
# print(len(ham_content)) 250

data = spam_content[0:500] + ham_content
# build vector
pipeline = Pipeline([('bag', CountVectorizer()), ('frequencies', TfidfTransformer())])
data = pipeline.fit_transform(data)
# print(data.shape[0]) 750
labels = np.array([0 for i in range(0, 500)] + [1 for i in range(0, 250)])
# print(labels.shape, data.shape)

# train test split
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.3, random_state=1)

# train
clf = RandomForestClassifier(random_state=0)
clf.fit(X_train, y_train)

# test
prediction = clf.predict(X_test)
accuracy = metrics.accuracy_score(y_test, prediction)
print('accuracy:', accuracy)
from sklearn.metrics import confusion_matrix

print('confusion matrix:')
print(confusion_matrix(y_test, prediction))
